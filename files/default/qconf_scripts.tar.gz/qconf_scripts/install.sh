#!/bin/sh

set +u

if [ "$SGE_ROOT" = "" ]; then
   echo error: SGE_ROOT must be set
   exit 1
fi

install_dir=$SGE_ROOT/util

if [ ! -d $install_dir ]; then
   echo error: $install_dir must be a directory
   exit 2
fi

if [ ! -w $install_dir ]; then
   echo error: you must have write access to $install_dir
   exit 3
fi

echo Installing files in $install_dir
cp qconf_add_attr qconf_add_list_value qconf_del_list_value qconf_mod_attr sge_edit_add_attr sge_edit_add_list_value sge_edit_del_list_value sge_edit_mod_attr $install_dir

for x in $SGE_ROOT/bin/*; do
   echo creating links in $x
   for a in qconf_add_attr qconf_add_list_value qconf_del_list_value qconf_mod_attr; do
      echo "    $x/$a"
      ln -s $install_dir/$a $x/$a
   done
done

